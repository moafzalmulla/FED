// remap jQuery to $
(function($){
	$(document).ready(function (){


	});
})(window.jQuery);